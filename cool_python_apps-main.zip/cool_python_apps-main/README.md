# cool_python_apps
Small and cool python apps including bitcoin mining, language translator etc.
